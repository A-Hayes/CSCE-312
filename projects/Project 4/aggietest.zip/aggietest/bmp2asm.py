#created for Project 4 of nand2tetris, specifically aggie.asm 
#function is to draw the letters 'ATM' from a bmp I made in 
#Paint, but this sould work with any properly sized bitmap
import os
import io
from PIL import Image, ImageOps
import numpy as np

#open image in grayscale mode
img = Image.open('ATM.bmp').convert('L')
#invert image, convert to array, set all nonzero bits to 1 to remove bit depth and ensure proper binary
img_inverted = ImageOps.invert(img)
np_img = np.array(img_inverted)
np_img[np_img > 0] = 1

#np_img is now a 2d array ([256][512]) of all bits, either 1 or 0

#newArr is a reformatted container that better groups bits into workable registers
newArr = np.zeros((256,32,16), dtype=np.int)

#copy contents of np_img into newArr
colCount=0
for i in range(256):
  for j in range(32):
    for k in range(16):
      newArr[i][j][k] = np_img[i][colCount]
      colCount+=1
  colCount=0   

#clear and recreate file to write asm instructions to, probably more elegant solution somewhere
os.remove("bmpInstruct.txt")
file = open('bmpInstruct.txt', 'w')

#loops thru newArr register by register, checks if there are any bits as to cut down on pointless
#instructions, writes formatted text string to file
regCounter = 16384
tempStr = ""
tempInt=0
for i in range(256):
  for j in range(32):
    if 1 in newArr[i][j]:
      for k in range(16):
        tempStr += str(newArr[i][j][k])
      #after k-loop creates string with all binary digits, convert bin to dec to get proper format
      tempInt = int(tempStr,2)
      file.write("\t@" + str(tempInt) + "\n")
      file.write("\tD=A\n")
      file.write("\t@" + str(regCounter) + "\n")
      file.write("\tM=D\n")
      tempStr = ""
      tempInt=0
    regCounter+=1

file.close()